# Copyright (C) 2019-2021 Intel Corporation
#
# SPDX-License-Identifier: MIT

from ..contexts.project import build_create_parser as build_parser

__all__ = [
    'build_parser',
]

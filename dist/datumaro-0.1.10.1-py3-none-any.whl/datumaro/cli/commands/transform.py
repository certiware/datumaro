# Copyright (C) 2020-2021 Intel Corporation
#
# SPDX-License-Identifier: MIT

from ..contexts.project import build_transform_parser as build_parser

__all__ = [
    'build_parser',
]
